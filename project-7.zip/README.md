# Project-7
Building a review restaurant app with React JS and Redux
Using Google Maps, Places API to fetch data, location
Users can add comment to a existing restaurant
Users can right click the map to add a new restaurant to it
